import axios, { AxiosRequestConfig } from "axios";
import { useAxios } from "./Axios";
import { IExpenseModel, IExpense, IUsers } from "./models"

interface ICrudService {
  addExpenses: (usersDetails: IExpenseModel) => Promise<IExpense>;
  getUsersExpenses: () => Promise<IExpense[]>;
  deleteExpenses: (id: number) => Promise<IExpense>;
  updateExpenses: (id: number, ExpenseInfo: IExpenseModel) => Promise<IExpense>;
  createUser: (userInfo: IUsers) => Promise<IUsers>;
  getUsers: () => Promise<IUsers[]>;
}

export function CrudService(): ICrudService {
  const axiosService = useAxios(
    axios.create({
      baseURL: "http://localhost:3000",
      headers: { "Content-Type": "application/json" }
    })
  );
  const loggedUser = () => {
    return JSON.parse(localStorage.getItem("user") || "{}")
  };

  const getUsersExpenses = () => {
    const user = loggedUser()
    const config: AxiosRequestConfig = {
      method: "get",
      url: `/expenses?userId=${user.id}`
    };
    return axiosService.makeRequest<IExpense[]>(config);
  };
  const deleteExpenses = (id: number) => {
    const config: AxiosRequestConfig = {
      method: "delete",
      url: `/expenses/${id}`
    };
    return axiosService.makeRequest<IExpense>(config);
  };
  const addExpenses = (ExpenseInfo: IExpenseModel) => {
    const user = loggedUser();
    const expenseData = {
      ...ExpenseInfo,
      userId: user.id
    }
    const config: AxiosRequestConfig = {
      method: "post",
      url: "/expenses",
      data: expenseData,
    };
    return axiosService.makeRequest<IExpense>(config);
  };
  const updateExpenses = (id: number, ExpenseInfo: IExpenseModel) => {
    const config: AxiosRequestConfig = {
      method: "patch",
      url: `/expenses/${id}`,
      data: ExpenseInfo,
    };
    return axiosService.makeRequest<IExpense>(config);
  };
  const createUser = (userInfo: IUsers) => {
    const config: AxiosRequestConfig = {
      method: "post",
      url: "/user",
      data: userInfo,
    };

    return axiosService.makeRequest<IUsers>(config);
  };
  const getUsers = () => {
    const config: AxiosRequestConfig = {
      method: "get",
      url: "/user",
    };

    return axiosService.makeRequest<IUsers[]>(config);
  };



  return {
    getUsersExpenses,
    deleteExpenses,
    addExpenses,
    updateExpenses,
    createUser,
    getUsers,
  }

}