import { useState } from 'react';
import {
    AppBar,
    Toolbar,
    Button,
    Box,
    Typography,
    DialogContentText,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import LogoutIcon from '@mui/icons-material/Logout';
import AccountCircleRoundedIcon from '@mui/icons-material/AccountCircleRounded';
import React from 'react';


const Navbar: React.FC = () => {
    const [open, setOpen] = useState(false);

    const navigate = useNavigate();
    const handleLogout = () => {
        localStorage.clear();
        navigate("/");
    }


    const handleOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };
    const user = JSON.parse(localStorage.getItem("user") || "{}");


    return (
        <React.Fragment>
            <AppBar position="fixed" sx={{ zIndex: 1201 }} >
                <Toolbar >
                    <Typography
                        variant="h4"
                        align="center"
                        sx={{
                            position: "absolute",
                            left: "50%",
                            transform: "translateX(-50%)"
                        }}
                    >
                        Expense Tracker
                    </Typography>

                    <Dialog open={open} onClose={handleClose}>
                        <DialogTitle>Confirm Delete</DialogTitle>
                        <DialogContent>
                            <DialogContentText>
                                Are you sure you want to Logout from the Expense Tracker ?
                            </DialogContentText>
                        </DialogContent>
                        <DialogActions>
                            <Button onClick={handleClose}>Cancel</Button>
                            <Button onClick={handleLogout} color="error" variant="contained">
                                Logout
                            </Button>

                        </DialogActions>
                    </Dialog>
                    
                    <Typography variant="h5" sx={{display:"flex",justifyContent: "flex-end", width: "850%" }}>
                        <AccountCircleRoundedIcon sx={{ fontSize: 30, mr: 1}}/>
                        Welcome {user.username}
                    </Typography>

                    <Box sx={{ display: "flex", justifyContent: "flex-end", width: "100%" }}>
                        <Button variant="contained" color="error" startIcon={<LogoutIcon />}
                            onClick={handleOpen} >
                            Logout
                        </Button>
                    </Box>

                </Toolbar>
            </AppBar>
        </React.Fragment>
    );
};

export default Navbar;
