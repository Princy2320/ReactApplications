export interface IUsers {
    id: number,
    username: string,
    password: string
    

}
export interface IExpense {
    id: number,
    userId: string;
    Title: string,
    Amount: string,
    Category: string,
    PaymentMode: string,
    Date: string

}


export interface IExpenseModel {

    Title: string,
    Amount: string,
    Category: string,
    PaymentMode: string,
    Date: string
}

