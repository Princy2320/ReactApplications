import { Autocomplete, Box, Button, Container, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, FormControlLabel, FormLabel, Grid, Radio, RadioGroup, Stack, TextField, Typography } from "@mui/material"
import React, { useState } from "react"
import { IExpenseModel } from "../../Services/models"
import { CrudService } from '../../Services/CrudService';
import FactCheckOutlinedIcon from '@mui/icons-material/FactCheckOutlined';

const AddExpense: React.FC<{ expenses: any; getUserExpense: () => void }> = (props) => {
    const [open, setOpen] = React.useState(false);
    const [Title, setTitle] = useState<string>("");
    const [Amount, setAmount] = useState<string>("");
    const [Category, setCategory] = useState<string>("");
    const [PaymentMode, setPaymentMode] = useState<string>("");
    const [Date, setDate] = useState<string>("");
    const [existingExpenses, setExistingExpenses] = useState<IExpenseModel[]>([]);
    const crudService = CrudService();
    const [errors, setErrors] = useState({
        Title: "",
        Amount: "",
        Category: "",
        PaymentMode: "",
        Date: ""
    });
    const expenseCategories = [
        "BusTicket",
        "Cab",
        "Train",
        "Dinner",
        "Lunch",
        "Swiggy/Zomato",
        "Insurance",
        "Medicine",
        "Shoes",
        "Dress",
        "Jewels",
        "Dairy Product",
        "Fruits",
        "Vegetables",
        "Movie",
        "Games",
        "Party"
    ];

    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
        setTitle("");
        setAmount("");
        setCategory("");
        setPaymentMode("");
        setDate("")
        setErrors({
            Title: "",
            Amount: "",
            Category: "",
            PaymentMode: "",
            Date: ""

        })
    };

    const validate = () => {
        let isValid = true;
        const newErrors = { Title: "", Amount: "", Category: "", PaymentMode: "", Date: "" };

        if (!Title.trim()) {
            newErrors.Title = "Title is required";
            isValid = false;
        }
        if (!Amount) {
            newErrors.Amount = "Amount is required";
            isValid = false;
        } else if (!/^\d+(\.\d{1,2})?$/.test(Amount)) {
            newErrors.Amount = "Enter a valid number (up to 2 decimals)";
            isValid = false;
        }
        if (!Category) {
            newErrors.Category = "Category is required";
            isValid = false;
        }
        if (!PaymentMode) {
            newErrors.PaymentMode = "PayementMode is required";
            isValid = false;
        }
        if (!Date) {
            newErrors.Date = "Date is required";
            isValid = false;
        }
        setErrors(newErrors);
        return isValid;
    };

    const handleNewExpense = () => {
        if (!validate()) return;
        const duplicate = props.expenses.some(
            (e: any) =>
                e.Title.toLowerCase() === Title.toLowerCase() &&
                e.Amount === Amount &&
                e.Category === Category &&
                e.PaymentMode === PaymentMode

        );

        if (duplicate) {
            alert(" This Expenses is already exists");
            return;
        }
        const ExpenseInfo: IExpenseModel = {
            Title: Title,
            Amount: Amount,
            Category: Category,
            PaymentMode: PaymentMode,
            Date: Date,
        }
        crudService.addExpenses(ExpenseInfo)
            .then(() => {
                props.getUserExpense();
                setExistingExpenses([...existingExpenses, ExpenseInfo]);
                handleClose()
            })
            .catch(() => {
                console.log("Create Failed")
            })
    };

    return (
        <React.Fragment>
            <Button variant="contained" endIcon={<FactCheckOutlinedIcon />}
                sx={{
                    xs: 12, md: 8
                }}
                onClick={handleClickOpen}>
                Create NewExpenses
            </Button>
            <Dialog open={open} onClose={handleClose}>
                <DialogTitle>Add NewExpenses</DialogTitle>
                <DialogContent>
                    <Container>
                        <Grid container spacing={2}>
                            <Grid >
                                <Typography> List of Expenses</Typography>

                                <TextField id="outlined-basic"
                                    placeholder="Title"
                                    name="Title"
                                    onChange={(e) => setTitle(e.target.value)}
                                    error={!!errors.Title}
                                    helperText={errors.Title} /> </Grid>
                            <Grid >
                                <Typography>Amount</Typography>
                                <TextField
                                    value={Amount}
                                    type=""
                                    onChange={(e) => setAmount(e.target.value)}
                                    error={!!errors.Amount}
                                    helperText={errors.Amount}
                                    placeholder="Enter amount"
                                    fullWidth
                                />
                            </Grid>
                            <Grid>
                                <Typography>Category</Typography>
                                <Autocomplete
                                    options={expenseCategories}
                                    value={Category || null}
                                    onChange={(event, newValue) => {
                                        setCategory(newValue || "");
                                    }}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            placeholder="Expense Category"
                                            variant="outlined"
                                            size="small"
                                            error={!!errors.Category}
                                            helperText={errors.Category}
                                        />
                                    )}
                                    sx={{ width: 250 }}
                                />
                            </Grid>
                            <Grid>

                                <FormControl>
                                    <FormLabel id="demo-radio-buttons-group-label">PaymentMode</FormLabel>
                                    <RadioGroup
                                        aria-labelledby="demo-radio-buttons-group-label"
                                        onChange={(e) => setPaymentMode(e.target.value)}
                                    >
                                        <FormControlLabel value="CreditCard" control={<Radio />} label="CreditCard" />
                                        <FormControlLabel value="DebitCard" control={<Radio />} label="DebitCard" />
                                        <FormControlLabel value="Cash" control={<Radio />} label="Cash" />
                                        <FormControlLabel value="UPI" control={<Radio />} label="UPI" />
                                    </RadioGroup>
                                </FormControl>

                            </Grid>
                            <Grid>
                                <Typography>Date</Typography>
                                <TextField id="outlined-basic"
                                    placeholder="Date"
                                    error={!!errors.Date}
                                    helperText={errors.Date}
                                    type="date"
                                    name="Date"
                                    onChange={(e) => setDate(e.target.value)}
                                /></Grid>
                        </Grid>
                    </Container>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleClose}>Cancel</Button>
                    <Button type="submit" variant="contained" onClick={handleNewExpense}>
                        Add NewExpense
                    </Button>
                </DialogActions>
            </Dialog>

        </React.Fragment>
    )
}


export default AddExpense;