import {
    Autocomplete,
    Button,
    Container,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    FormControl,
    FormControlLabel,
    FormLabel,
    Grid,
    Radio,
    RadioGroup,
    TextField,
    Typography
} from "@mui/material"
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import React, { useState } from "react"
import { IExpense, IExpenseModel } from "../../Services/models"
import { CrudService } from '../../Services/CrudService';

const UpdateExpense: React.FC<{ getUserExpense: () => void; userExpense: IExpense }> = (props) => {
    const [open, setOpen] = React.useState(false);
    const [Title, setTitle] = useState<string>(props?.userExpense.Title);
    const [Amount, setAmount] = useState<string>(props?.userExpense.Amount);
    const [Category, setCategory] = useState<string>(props?.userExpense.Category);
    const [PaymentMode, setPaymentMode] = useState<string>(props?.userExpense.PaymentMode);
    const [Date, setDate] = useState<string>(props?.userExpense.Date);
    const [amountError, setAmountError] = useState("");
    const crudService = CrudService();

    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };

    const handleUpdteExpense = () => {
        const ExpenseInfo: IExpenseModel = {
            Title: Title,
            Amount: Amount,
            Category: Category,
            PaymentMode: PaymentMode,
            Date: Date,
        }
        crudService.updateExpenses(props?.userExpense?.id, ExpenseInfo)
            .then((result) => {
                props.getUserExpense()
                handleClose()
            })
            .catch((error) => {
                console.log("Create Failed")
            })
    };
    const expenseCategories = [
        "BusTicket",
        "Cab",
        "Train",
        "Dinner",
        "Lunch",
        "Swiggy/Zomato",
        "Insurance",
        "Medicine",
        "Shoes",
        "Dress",
        "Jewels",
        "Dairy Product",
        "Fruits",
        "Vegetables",
        "Movie",
        "Games",
        "Party"
    ];

    const handleAmountChange = (e: any) => {
        const value = e.target.value;
        if (value === "" || /^\d+(\.\d{0,2})?$/.test(value)) {
            setAmount(value);
        } else {
            setAmountError("Enter a valid amount");
        }
    };

    return (
        <React.Fragment>
            <Button variant="contained"
                startIcon={<EditOutlinedIcon />}
                onClick={handleClickOpen}>
                Update
            </Button>
            <Dialog open={open} onClose={handleClose}>
                <DialogTitle>Update NewExpenses</DialogTitle>
                <DialogContent>
                    <Container>
                        <Grid container spacing={4}>
                            <Grid >
                                <Typography>Title</Typography>
                                <TextField id="outlined-basic"
                                    placeholder="Title"
                                    name="Title"
                                    value={Title}
                                    onChange={(e) => setTitle(e.target.value)} /> </Grid>
                            <Grid >
                                <Typography>Amount</Typography>
                                <TextField
                                    placeholder="Amount"
                                    value={Amount}
                                    onChange={handleAmountChange}
                                    error={!!amountError}
                                    helperText={amountError}
                                    variant="outlined"
                                    size="small"
                                    fullWidth
                                />
                            </Grid>
                            <Grid>
                                <Typography>Category</Typography>
                                <Autocomplete
                                    options={expenseCategories}
                                    value={Category || null}

                                    onChange={(event, newValue) => {
                                        setCategory(newValue || "");
                                    }}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            placeholder="Expense Category"
                                            variant="outlined"
                                            size="small"
                                        />
                                    )}
                                    sx={{ width: 250 }}
                                />
                            </Grid>
                            <Grid>
                                <FormControl>
                                    <FormLabel id="demo-radio-buttons-group-label">PaymentMode</FormLabel>
                                    <RadioGroup
                                        value={PaymentMode}
                                        aria-labelledby="demo-radio-buttons-group-label"
                                        onChange={(e) => setPaymentMode(e.target.value)}
                                    >
                                        <FormControlLabel value="CreditCard" control={<Radio />} label="CreditCard" />
                                        <FormControlLabel value="DebitCard" control={<Radio />} label="DebitCard" />
                                        <FormControlLabel value="Cash" control={<Radio />} label="Cash" />
                                        <FormControlLabel value="UPI" control={<Radio />} label="UPI" />
                                    </RadioGroup>

                                </FormControl>

                            </Grid>
                            <Grid>
                                <Typography>Date</Typography>
                                <TextField id="outlined-basic"
                                    value={Date}
                                    placeholder="Date"
                                    type="date"
                                    name="Date"
                                    onChange={(e) => setDate(e.target.value)}
                                /></Grid>

                        </Grid>
                    </Container>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleClose}>Cancel</Button>
                    <Button variant="contained" onClick={handleUpdteExpense}>
                        Update
                    </Button>
                </DialogActions>
            </Dialog>

        </React.Fragment>
    )
}


export default UpdateExpense;

