import React from 'react';
import { Routes, Route,  BrowserRouter } from 'react-router-dom';

import LoginPage from './Pages/LoginPage';
import Expenses from './Components/CrudDetails/Expenses';
import Signup from './Pages/Signup';


function App() {
  return (
    <BrowserRouter>
     
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/signup" element ={<Signup/>}/>
        <Route path="/expenses" element={<Expenses />} />
     
      </Routes>
    </BrowserRouter>

  );
};
    
    


export default App;
