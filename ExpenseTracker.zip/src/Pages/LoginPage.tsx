import React, { useEffect, useState } from "react";
import { Box, TextField, Button, Typography, Card, CardContent, Zoom } from "@mui/material";
import { useNavigate } from "react-router-dom";
import LoginIcon from '@mui/icons-material/Login';
import CoverImages from "../Images/image.jpg"
import { CrudService } from '../Services/CrudService';


const LoginPage: React.FC = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [usernameError, setUsernameError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const navigate = useNavigate();
  const crudService = CrudService();
  const [checked, setChecked] = React.useState(true);
 
  
  const handleLogin = async () => {
    setUsernameError("");
    setPasswordError("");

    if (!username || !password) {
      setUsernameError("Required Username");
      setPasswordError("Required Password");
      return;
    }

    const user = await crudService.getUsers();

    const users = user.find((e) => e.username === username);

    if (!users) {
      setUsernameError("Invalid username");
      return;
    }
    if (users.password !== password) {
      setPasswordError("Invalid password");
      return;
    }

    localStorage.setItem("user", JSON.stringify(users));
    navigate("/expenses");
  };


  return (
    <React.Fragment>
      <Box sx={{
        backgroundImage: `url(${CoverImages})`,
        backgroundRepeat: "no-repeat", backgroundSize: "cover", height: "100vh"
      }}>
        <Typography variant="h4" mb={2} align="center"
          sx={{ color: "#091121", fontWeight: 600 }}
        > Expense Tracker Management </Typography>

        <Box display="flex" justifyContent="center" mt={10}>
          <Zoom in={checked} timeout= {1000} appear={true} style={{ transitionDelay: checked ? '500ms' : '0ms' }}>
            <Card sx={{ width: 400 }}>
              <CardContent>
                <Typography variant="h5" align="center">
                  Login
                </Typography>

                <TextField
                  label="Username"
                  fullWidth
                  margin="normal"
                  value={username}
                  error={!!usernameError}
                  helperText={usernameError}
                  onChange={(e) => setUsername(e.target.value)}
                />

                <TextField
                  label="Password"
                  type="password"
                  fullWidth
                  margin="normal"
                  value={password}
                  error={!!passwordError}
                  helperText={passwordError}
                  onChange={(e) => setPassword(e.target.value)}
                />

                <Button
                  variant="contained"
                  color="success"
                  fullWidth
                  sx={{ mt: 2 }}
                  startIcon={<LoginIcon />}
                  onClick={handleLogin}
                >
                  LOGIN
                </Button>
                <Button
                  fullWidth
                  sx={{ mt: 1 }}
                  onClick={() => navigate("/signup")}
                >
                  New user? Sign Up
                </Button>
              </CardContent>
            </Card>
          </Zoom>
        </Box>
        <Box sx={{ display: 'flex' }}>

        </Box>
      </Box>

    </React.Fragment >
  );
};

export default LoginPage;