import React, { useEffect, useState } from 'react';
import {
  Button,
  TextField,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Stack,
  TablePagination,
  Autocomplete,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
  CircularProgress,
  Box,
  Toolbar,
  CardContent,
  Card,
  IconButton,
  Drawer,
  Skeleton,
} from "@mui/material";
import DeleteIcon from '@mui/icons-material/Delete';
import LocalAtmIcon from '@mui/icons-material/LocalAtm';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import { IExpense } from '../../Services/models';
import { CrudService } from '../../Services/CrudService';
import AddExpense from './AddExpenses';
import UpdateExpense from './UpdateExpenses';
import Navbar from '../NavBar';
import DeleteExpenses from "./DeleteExpenses";
const drawerWidth = 250;


const Expenses = () => {
  const [expenses, setExpenses] = useState<IExpense[]>([]);
  const [page, setPage] = useState(0);
  const [totalRecords, setTotoalRecords] = useState<number>(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [searchInput, setSearchInput] = useState("");
  const [Category, setCategory] = useState<string>('All');
  const [PaymentMode, setPaymentMode] = useState<string>('All');
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [selectedExpenseId, setSelectedExpenseId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [openLoading, setOpenLoading] = useState(true);
  const crudService = CrudService();


  useEffect(() => {
    getUserExpenses();
  }, []);


  const getUserExpenses = () => {
    setOpenLoading(true);
    crudService.getUsersExpenses().then((response: Array<IExpense>) => {
      setExpenses(response);
      setTotoalRecords(response.length);
    }).finally(() => {
      const delay = setTimeout(() => {
        setOpenLoading(false);
      }, 3000);

      return () => clearTimeout(delay);
    });

  }

  const deleteExpenses = (id: number) => {
    crudService.deleteExpenses(id).then((response) => {
      getUserExpenses();
    })
  }
  const handleConfirmDelete = () => {
    if (selectedExpenseId !== null) {
      deleteExpenses(selectedExpenseId);
    }
    setOpenDeleteDialog(false);
    setSelectedExpenseId(null);
  };

  const handleCancelDelete = () => {
    setOpenDeleteDialog(false);
    setSelectedExpenseId(null);
  };

  const filterData = expenses.filter((expenseItem) => {
    const matchedSearch = expenseItem?.Title.toLowerCase().includes(searchInput.toLowerCase())
    const matchedCategory = Category === 'All' || expenseItem.Category === Category;
    const matchedPaymentMode = PaymentMode === 'All' || expenseItem.PaymentMode === PaymentMode;
    return matchedSearch && matchedCategory && matchedPaymentMode;

  });

  const totalExpensesCount = expenses.length;
  const totalExpensesAmount = expenses.reduce(
    (sum, expense) => sum + Number(expense.Amount),
    0
  );
  const thisMonthTotal = expenses.filter(e =>
    new Date(e.Date).getMonth() === new Date().getMonth()
  ).reduce((sum, e) => sum + Number(e.Amount), 0);

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: any) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const expenseCategories = [
    "BusTicket",
    "Cab",
    "Train",
    "Dinner",
    "Lunch",
    "Swiggy/Zomato",
    "Insurance",
    "Medicine",
    "Shoes",
    "Dress",
    "Jewels",
    "Dairy Product",
    "Fruits",
    "Vegetables",
    "Movie",
    "Games",
    "Party"
  ];

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false)
    }, 1000)
    return () => clearTimeout(timer);
  }, [])

  if (loading) {
    return (
      <Box sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '700px'
      }}>
        <CircularProgress size="3rem" />
        <Typography> LoadingExpenses....</Typography>
      </Box>
    );
  }

  return (
    <React.Fragment>
      <Navbar />
      <Box sx={{
        backgroundColor: "beige", height: "96vh"
      }}>
        <Drawer
          variant="permanent"
          sx={{
            width: drawerWidth,
            flexShrink: 0, mt: 8,
            [`& .MuiDrawer-paper`]: {
              width: drawerWidth,
              backgroundColor: "beige",
              display: "flex",
              flexDirection: "column",
            },
          }}
        ><Box padding={4}>
            <Typography variant="h6" mb={2} mt={8}>
              Search & Filter
            </Typography>
            <TextField
              label="Search by Title"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              sx={{ mb: 2 }}
            />
            <Autocomplete
              options={expenseCategories}
              value={Category || null}
              onChange={(e, newValue) => setCategory(newValue || "")}
              renderInput={(params) => (
                <TextField {...params} label="Filter by Category" />
              )}
              sx={{ mb: 3 }}
            />
            <FormControl>
              <FormLabel>Payment Mode</FormLabel>
              <RadioGroup
                value={PaymentMode}
                onChange={(e) => setPaymentMode(e.target.value)}
              >
                <FormControlLabel value="All" control={<Radio />} label="All" />
                <FormControlLabel value="CreditCard" control={<Radio />} label="Credit" />
                <FormControlLabel value="DebitCard" control={<Radio />} label="Debit" />
                <FormControlLabel value="Cash" control={<Radio />} label="Cash" />
                <FormControlLabel value="UPI" control={<Radio />} label="UPI" />
              </RadioGroup>
            </FormControl>
          </Box>
        </Drawer>
        <Box component="main" sx={{ flexGrow: 1, p: 3, mb: 3, ml: `${drawerWidth}px` }}>
          <Stack direction="row" spacing={9} sx={{ ml: 30, mb: 1 }} >
            <Card sx={{
              xs: 12, md: 4, width: 200,
              backgroundColor: 'lightblue', '&:hover': { boxShadow: 6 }, borderRadius: 3
            }}>

              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <IconButton >
                    <ShoppingCartIcon />
                  </IconButton>
                  <Typography >Total Expenses</Typography></Box>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Typography variant="h4" color="text.secondary"
                    sx={{ marginLeft: 9, fontWeight: 'bold' }}>
                    {totalExpensesCount}
                  </Typography></Box>
              </CardContent>
            </Card>
            <Box>
              <Card sx={{
                xs: 12, md: 4, width: 230,
                backgroundColor: 'lightblue', '&:hover': { boxShadow: 6 }, borderRadius: 3
              }}>
                <CardContent >
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <IconButton >
                      <LocalAtmIcon />
                    </IconButton>
                    <Typography >Total Expense Amount</Typography></Box>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Typography variant="h4" color="text.secondary"
                      sx={{ fontWeight: 'bold', marginLeft: 2 }}>
                      ₹{totalExpensesAmount.toFixed(2)}
                    </Typography></Box>
                </CardContent>
              </Card>
            </Box>
            <Card sx={{
              xs: 12, md: 4, width: 250,
              backgroundColor: 'lightblue', '&:hover': { boxShadow: 6 }, borderRadius: 3
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <IconButton >
                    <CalendarMonthIcon />
                  </IconButton>
                  <Typography >Month Expenses</Typography></Box>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Typography variant="h4" color="text.secondary" sx={{ marginLeft: 3, fontWeight: 'bold' }}>
                    ₹{thisMonthTotal.toFixed(2)}
                  </Typography></Box>
              </CardContent>
            </Card>
          </Stack>
          <Toolbar>
            <AddExpense getUserExpense={getUserExpenses}
              expenses={expenses} />
            <Typography variant="h6" align="center"
              sx={{
                position: "absolute",
                left: "50%",
                transform: "translateX(-50%)"
              }}>
              List of Expenses
            </Typography></Toolbar>
          <TableContainer
            component={Paper}
            sx={{ boxShadow: 6, borderRadius: 3, backgroundColor: "#fafafa" }}
          >                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
            <Table>
              <TableHead>
                <TableRow sx={{ backgroundColor: "lightblue" }}>
                  <TableCell>Title</TableCell>
                  <TableCell>Amount</TableCell>
                  <TableCell>Category</TableCell>
                  <TableCell>PayementMode</TableCell>
                  <TableCell>Date</TableCell>
                  <TableCell>Action </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {openLoading
                  ? Array.from({ length: 6 }).map((_, i) => (
                    <TableRow key={i} sx={{ maxWidth: 100 }}>
                      {Array.from({ length: 6 }).map((_, j) => (
                        <TableCell key={j} sx={{ maxWidth: 1 }}>
                          <Skeleton animation="pulse"
                            sx={{ bgcolor: "#9dd2e3" }}
                            variant="text"
                            width="100%"
                          />
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                  : filterData.length > 0 ? (
                    filterData
                      .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                      .map((expense) => (
                        <TableRow key={expense.id}>
                          <TableCell>{expense.Title}</TableCell>
                          <TableCell>₹{expense.Amount}</TableCell>
                          <TableCell>{expense.Category}</TableCell>
                          <TableCell>{expense.PaymentMode}</TableCell>
                          <TableCell>{expense.Date}</TableCell>
                          <TableCell>

                            <Stack direction="row" spacing={1}>
                              <UpdateExpense
                                getUserExpense={getUserExpenses}
                                userExpense={expense}
                              />
                              <Button
                                size="small"
                                variant="outlined"
                                color="error"
                                startIcon={<DeleteIcon />}
                                onClick={() => {
                                  setSelectedExpenseId(expense.id);
                                  setOpenDeleteDialog(true);
                                }}
                              > Delete
                              </Button>
                            </Stack>
                          </TableCell>
                        </TableRow>
                      ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={9} align="center">
                        <Typography>No Expenses Found</Typography>
                      </TableCell>
                    </TableRow>
                  )}
              </TableBody>
            </Table>
            <TablePagination
              rowsPerPageOptions={[5, 10, 20, 50]}
              component="div"
              count={totalRecords}
              rowsPerPage={rowsPerPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
            />
          </TableContainer>
        </Box>
      </Box >
      <DeleteExpenses
        open={openDeleteDialog}
        onClose={handleCancelDelete}
        onConfirm={handleConfirmDelete}
      />

    </React.Fragment >
  );
};

export default Expenses;
