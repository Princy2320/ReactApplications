import React, { useState } from "react";
import {
    Box,
    TextField,
    Button,
    Typography,
    Card,
    CardContent,
    Zoom
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { CrudService } from "../Services/CrudService";
import CoverImages from "../Images/image.jpg"

const Signup: React.FC = () => {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [usernameError, setUsernameError] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [error, setError] = useState("");
    const [checked, setChecked] = React.useState(true);


    const navigate = useNavigate();
    const crudService = CrudService();

    const handleSignup = async () => {
        if (!username || !password) {
            setUsernameError("Required Username");
            setPasswordError("Required Password");
            return;
        }
        const user = await crudService.getUsers();

        const userExists = user.some(
            (u) => u.username === username
        );

        if (userExists) {
            setError("Username already exists");
            return;
        }

        await crudService.createUser({
            username,
            password,
            id: 0
        });
        alert("Signup successful");
        navigate("/");
    };

    return (
        <React.Fragment>
            <Box sx={{
                backgroundImage: `url(${CoverImages})`,
                backgroundRepeat: "no-repeat", backgroundSize: "cover", height: "100vh"
            }}>
                <Typography variant="h4" mb={2} align="center"
                    sx={{ color: "#091121", fontWeight: 600 }}
                > Expense Tracker Management </Typography>
                <Box display="flex" justifyContent="center" mt={10}>
                    <Zoom in={checked} appear={true} style={{ transitionDelay: checked ? '500ms' : '1500ms' }}>
                        <Card sx={{ width: 400 }}>
                            <CardContent>
                                <Typography variant="h5" align="center">
                                    Sign Up
                                </Typography>

                                <TextField
                                    label="Username"
                                    fullWidth
                                    margin="normal"
                                    value={username}
                                    error={!!usernameError}
                                    helperText={usernameError}
                                    onChange={(e) => setUsername(e.target.value)}
                                />
                                <TextField
                                    label="Password"
                                    type="password"
                                    fullWidth
                                    margin="normal"
                                    value={password}
                                    error={!!passwordError}
                                    helperText={passwordError}
                                    onChange={(e) => setPassword(e.target.value)}
                                />
                                <Button
                                    variant="contained"
                                    fullWidth
                                    sx={{ mt: 2 }}
                                    onClick={handleSignup}
                                >
                                    SIGN UP
                                </Button>

                                <Button
                                    fullWidth
                                    sx={{ mt: 1 }}
                                    onClick={() => navigate("/")}
                                >
                                    Already have an account? Login
                                </Button>
                            </CardContent>
                        </Card>
                    </Zoom>
                </Box>
            </Box>
        </React.Fragment>
    );
};

export default Signup;
